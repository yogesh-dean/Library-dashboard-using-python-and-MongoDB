import streamlit as st
import pymongo

myclient=pymongo.MongoClient("mongodb://localhost:27017")
mydb=myclient["centrallibrary"]
mycol1=mydb["student"]
mycol2=mydb["BOOKS"]
#fuctions add student
def student_add(name,student_id,dept,book):
   data={"name":name,"student_id":student_id,"dept":dept,"book":book}
   x=mycol1.insert_one(data)
   

#fuction view student
def student_view(student_id):
    if mycol1.find_one({"student_id":student_id}):
      st.success("Id found successfully")
      student=mycol1.find_one({"student_id":student_id})
      st.write(student)
    else:
      st.error("Invalid id")

#function add book
def add_book(book_name,authour):
   data={"book_name":book_name,"author":authour}  
   x=mycol2.insert_one(data)
   print(x)

#function find book
def view_book(book_name):
    if(mycol2.find_one({"book_name":book_name})):
      st.success("Book found successfully")
      book = mycol2.find_one({"book_name":book_name})
      st.write(book)
    else:  
       st.error("Invalid book name")


def main(): 
    st.title("CENTRAL LIBRARY") 
    


    st.sidebar.title("STUDENT")
    page = st.sidebar.selectbox("Student Details", ['home','student details', 'add student'])

    if page == "home":
        st.write("Please Maintain Silence!!")
    elif(page== "student details") :
        st.header("Student Details")
        student_id= st.number_input("Enter student id:")
        student_view(student_id)

    
    elif page == "add student":
        if("add student"):

            st.header("Add Student")
            name = st.text_input("Enter the student name:")
            student_id=st.number_input("Enter id:")
            dept=st.text_input("Enter the dept:")
            book=st.number_input("Enter books:")
            if st.button("click to insert"):
            
                student_add(name,student_id,dept,book)
                st.balloons()

    st.sidebar.title("BOOKS")
    note = st.sidebar.selectbox("Books Details", ['home','book details', 'add books'])

    if note == "home":
        print("")
    elif(note=="book details"):
        st.header("Book Details")
        book_name = st.text_input("Enter book name:")
        view_book(book_name)
    
    
    elif note == "add books":
        if("add books"):
            st.header("Add Books")
            book_name = st.text_input("Enter the book name:")
            authour=st.text_input("Enter the authour")
            if st.button("click here to insert"):
             add_book(book_name,authour)
             st.snow()
main()